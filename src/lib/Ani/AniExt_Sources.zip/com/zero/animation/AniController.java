package com.zero.animation;

import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This class provides utility methods if you're planning on using several animations. It'll take care of allocating
 * and cleaning controllers as needed.
 *
 * @author Z3R0x24
 */
public class AniController {
    private final int targetFPS_millis;
    private final ConcurrentHashMap<HashSet<BaseAnimation>, Ani> controllers;
    private Ani current_controller = null;
    private HashSet<BaseAnimation> currentSet = null;
    private int totalAnimations;
    private final int period;

    private Timer timer = null;

    /**
     * Creates a new instance of the controller with the specified target FPS and cleanup period.
     * While targetFPS is generally expected to be > 0, it can be set to 0 to specify unlocked framerate.
     * The cleanup period can also be set to 0, however, this means no cleanup.
     * @param targetFPS Desired framerate for all animations using this controller.
     * @param period Cleanup period. Empty controllers will be cleaned after the specified time in millis has passed.
     */
    public AniController(int targetFPS, int period) {
        if (period < 0)
            throw new IllegalArgumentException("Cleanup period must be >= 0");

        targetFPS_millis = FPS_millis(targetFPS);
        this.period = period;
        controllers = new ConcurrentHashMap<>();
    }

    /**
     * Default constructor with target framerate of 60 FPS and a cleanup period of 2 minutes.
     */
    public AniController() {
        this(60, 2*60_000);
    }

    /**
     * Initializes the cleanup timer. The timer will keep running until all empty controllers have been cleaned, at this
     * point, the timer will cancel itself and be set to null. It will automatically be re initialized the next time a
     * controller is needed.
     * @see AniController#changeController()
     */
    private void initCleanup() {
        if (period > 0) {
            timer = new Timer();
            timer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    for (HashSet<BaseAnimation> set : controllers.keySet()) {
                        Ani controller = controllers.get(set);
                        if (controller != null && controller.empty()) {
                            controllers.remove(set);
                            controller.clear();
                        }
                    }

                    if (controllers.size() == 0 && timer != null) {
                        timer.cancel();
                        timer = null;
                    }
                }
            }, period, period);
        }
    }

    /**
     * Creates a new instance of the {@code Ani} controller with the specified max size for animations. This method is generally
     * called if the previous controller is full or an array with length greater than the default max size of a
     * controller is passed to the {@code add()} method.
     * It will initialize the cleanup task upon adding a controller.
     * @param size Max size of the controller.
     */
    protected void changeController(int size) {
        current_controller = new Ani(size, targetFPS_millis);
        currentSet = new IndexedHashSet<>();
        controllers.put(currentSet, current_controller);

        if (timer == null)
            initCleanup();
    }

    /**
     * Creates a new instance of the Ani controller with the default max size.
     * @see AniController#changeController(int)
     */
    protected void changeController() {
        changeController(Ani.defaultLimit);
    }

    /**
     * Adds an animation to the current controller. This method guarantees that the animation will be added to a
     * controller.
     * @param delay Time, in millis, before the animation starts.
     * @param animation Animation to be added.
     */
    public void add(int delay, BaseAnimation animation) {
        if (current_controller == null || current_controller.full()) {
            changeController();
        }

        if (animation != null) {
            animation.addFinishedListener(pAnimation -> {
                currentSet.remove(pAnimation);
                totalAnimations--;
            });

            current_controller.add(delay, animation);
            currentSet.add(animation);
            totalAnimations++;
        }
    }

    /**
     * Adds an animation to a free controller with no delay.
     * @param animation Animation to be added.
     */
    public void add(BaseAnimation animation) {
        add(-1, animation);
    }

    /**
     * Adds an array of animations to the current controller, if possible. In case the array doesn't fit in an empty
     * controller (this is, {@code array.length > controller.animationsLimit}), it will create a new controller which
     * limit matches the array length.
     * It will also add an {@code AnimationFinishedListener}, if provided, that will be called when all animations on
     * the array finish running.
     * @param allDone Listener to call on all animations finish.
     * @param animations Animation array to add.
     * @return True if the animation array was added.
     */
    protected boolean addBulk(AnimationFinishedListener allDone, BaseAnimation[] animations) {
        if (current_controller == null)
            changeController();

        if (animations.length > current_controller.getLimit())
            changeController(animations.length);

        if (current_controller.add(allDone, animations)) {
            for (BaseAnimation a : animations) {
                currentSet.add(a);

                a.addFinishedListener(pAnimation -> {
                    currentSet.remove(pAnimation);
                    totalAnimations--;
                });
            }

            totalAnimations += animations.length;
            return true;
        }

        return false;
    }

    /**
     * Adds several animations and an {@code AnimationFinishedListener} to be called after all animations have
     * finished playing.
     * @param allDone Listener to call on all animations finish.
     * @param animations Animations to add.
     */
    public void add(AnimationFinishedListener allDone, BaseAnimation... animations) {
        if (!addBulk(allDone, animations)) {
            changeController();
            addBulk(allDone, animations);
        }
    }

    /**
     * Adds several animations.
     * @param animations Animations to be added.
     */
    public void add(BaseAnimation... animations) {
        add(null, animations);
    }

    /**
     * Adds a sequence of animations that will play one after another, in order, and a listener to be called when the
     * sequence is done playing.
     * @param allDone Listener to call on sequence end.
     * @param animations Animations to add to the sequence.
     */
    public void addSequence(AnimationFinishedListener allDone, BaseAnimation... animations) {
        if (current_controller == null)
            changeController();

        if (animations.length > current_controller.getLimit())
            changeController(animations.length);

        if (!current_controller.addSequence(allDone, animations)) {
            changeController();
            current_controller.addSequence(allDone, animations);
        }
    }

    /**
     * Adds a sequence of animations that will play one after another, in order.
     * @param animations Animations to add to the sequence.
     */
    public void addSequence(BaseAnimation... animations) {
        addSequence(null, animations);
    }

    /**
     * Obtains the controller in which the specified animation is registered.
     * @param animation Animation belonging to the controller.
     * @return Controller containing the animation, if existent.
     */
    public Ani getController(BaseAnimation animation) {
        if (currentSet == null)
            return null;

        if (currentSet.contains(animation))
            return current_controller;

        for (HashSet<BaseAnimation> set: controllers.keySet())
            if (set.contains(animation))
                return controllers.get(set);

        return null;
    }

    /**
     * Stops an animation gracefully. Calls its finishing listeners.
     * @param animation Animation to be stopped.
     * @return True if the animation was found, and stopped.
     */
    public boolean stop(BaseAnimation animation) {
        Ani controller;

        if ((controller = getController(animation)) != null) {
            totalAnimations--;
            return controller.stop(animation);
        }

        return false;
    }

    /**
     * Stops an animation the hard way. Does not call its finishing listeners.
     * @param animation Animation to be canceled.
     * @return True if the animation was found and cancelled.
     */
    public boolean cancel(BaseAnimation animation) {
        Ani controller;

        if ((controller = getController(animation)) != null) {
            totalAnimations--;
            return controller.cancel(animation);
        }

        return false;
    }

    /**
     * Completely clears all controllers. This method can be rather time consuming, so it's advised to call it only if
     *  necessary.
     */
    public void purge() {
        for (HashSet<BaseAnimation> set: controllers.keySet()) {
            set.clear();
            controllers.get(set).clear();
        }

        totalAnimations = 0;
        controllers.clear();
        current_controller = null;
        currentSet = null;
    }

    /**
     * Gets the total amount of animations currently registered.
     * @return Total amount of animations.
     */
    public int getTotalAnimations() {
        return totalAnimations;
    }

    /**
     * Returns the millisecond value appropriate for an update interval to display the specified frames per second.
     * This means that the update frequency matches (or is very close to) the desired framerate.
     * @param fps Target framerate.
     * @return Delay between frames, in milliseconds.
     */
    public static int FPS_millis(int fps) {
        if (fps < 0 || fps > 1000)
            throw new IllegalArgumentException("FPS value must be between 0 and 1000");

        if (fps == 0)
            return 0;
        else
            return 1000 / fps;
    }

    private static int setIndex = 0;

    /**
     * LinkedHashSet implementation utilizing a final index as hashcode. This is necessary in order for the
     * ConcurrentHashMap to find the value mapped to it, since hashCodes of regular LinkedHashSets seem to change based
     * on its contents.
     * @param <E>
     */
    private static class IndexedHashSet<E> extends HashSet<E> {
        final int index;

        public IndexedHashSet() {
            super();
            index = setIndex;
            setIndex++;
        }

        @Override
        public int hashCode() {
            return index;
        }
    }
}
