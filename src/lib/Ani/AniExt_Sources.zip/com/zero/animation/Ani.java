package com.zero.animation;

import com.zero.animation.Collection.HashedArray;

import java.util.*;

/**
 * A controller to add and update animations.
 *
 * @author lucahofmann@gmx.net
 * @author Z3R0x24
 */
public class Ani {

	/**
	 * The global time factor used for all animations.
	 */
	public static float globalAnimationTimeFactor = 1.0f;
	public static final int defaultLimit = 100;

	private final int animationsLimit;

	/**
	 * The animations to control.
	 */
	private final HashedArray<BaseAnimation> animations;

	private final HashSet<AnimationFinishedListener> allAnimationsFinishedListeners;


	/**
	 * A time to schedule animation updates or null.
	 */
	private Timer timer = null;
	private boolean enabled = true;
	private volatile boolean run = true;

	/**
	 * Creates a new animation controller. Use this if you want to update animations
	 * on your own (e.g. every render frame)
	 *
	 */
	public Ani(int size, int pInterval) {
		animationsLimit = size;
		animations = new HashedArray<>(size);
		allAnimationsFinishedListeners = new HashSet<>(animationsLimit);

		if (pInterval < 0)
			throw new IllegalArgumentException("Update interval must be >= 0");


		if (pInterval > 0) {
			timer = new Timer();
			TimerTask timerTask = new TimerTask() {
				@Override
				public void run() {
					update();
				}
			};
			timer.schedule(timerTask, pInterval, pInterval);
		} else {
			new Thread(() -> {
				while (run) {
					update();
				}
			}).start();
		}
	}

	/**
	 * Creates a new animation controller. Updates it self
	 * every pInterval milliseconds.
	 * @param pInterval The update interval in milliseconds.
	 */
	public Ani(int pInterval) {
		this(defaultLimit, pInterval);
	}

	/**
	 * Adds an animation.
	 *
	 * @param pAnimation The animation to add.
	 * @return true if the animation was added.
	 */
	public boolean add(BaseAnimation pAnimation) {
		if (!enabled || animations.size() >= animationsLimit) {
			return false;
		}
		if (pAnimation != null) {
			if (pAnimation.getTimeStartPlaned() == -1 && !pAnimation.hasStarted()) {
				pAnimation.start();
			}
			animations.add(pAnimation);
			return true;
		}
		return false;
	}

	/**
	 * Adds an animation with a start delay.
	 *
	 * @param pStartDelayMillis A delay to start the animation in milliseconds.
	 * @param pAnimation The animation to add.
	 * @return true if the animation was added.
	 */
	public boolean add(final int pStartDelayMillis, final BaseAnimation pAnimation) {
		if (pStartDelayMillis > 0 && enabled) {
			pAnimation.setTimeStartPlaned(System.currentTimeMillis() + pStartDelayMillis);
		}

		return add(pAnimation);
	}

	/**
	 * Adds multiple animations and a listener to fall if all are finished.
	 * @param pAllAnimationFinishedListener The listener to call is all animations are finished.
	 * @param pAnimations The animations.
	 * @return true if the animations were added.
	 */
	public boolean add(AnimationFinishedListener pAllAnimationFinishedListener, BaseAnimation... pAnimations) {
		if (!enabled || pAnimations == null || pAnimations.length == 0 ||
				pAnimations.length > animationsLimit - animations.size()) {
			return false;
		}

		AnimationsFinishedCollector finishedCollector = null;
		if (pAllAnimationFinishedListener != null) {
			finishedCollector = new AnimationsFinishedCollector(pAnimations.length,
					pAllAnimationFinishedListener);
		}

		for (BaseAnimation animation : pAnimations) {
			if (finishedCollector != null) {
				animation.addFinishedListener(finishedCollector);
			}
			add(animation);
		}
		return true;
	}

	/**
	 * Adds multiple animations.
	 * @param pAnimations The animations.
	 * @return true if the animations were added.
	 */
	public boolean add(final BaseAnimation... pAnimations) {
		return add(null, pAnimations);
	}

	/**
	 * Adds a sequence of animations that will be added one after another.
	 * @param pSequenceFinishedListener A listener that gets called if the sequence has ended.
	 * @param pAnimations The animation sequence to add.
	 * @return true if the sequence was added.
	 */
	public boolean addSequence(AnimationFinishedListener pSequenceFinishedListener, BaseAnimation... pAnimations) {
		if (!enabled || pAnimations == null || pAnimations.length == 0 || full()) {
			return false;
		}

		if (pAnimations.length == 1) {
			add(pAnimations[0]);
			return true;
		}

		for (int i = 0; i < pAnimations.length - 1; i++) {
			final BaseAnimation animation = pAnimations[i];
			final int finalI = i;
			animation.addFinishedListener(pAnimation -> add(pAnimations[finalI + 1]));
		}

		if (pSequenceFinishedListener != null)
			pAnimations[pAnimations.length - 1].addFinishedListener(pSequenceFinishedListener);

		add(pAnimations[0]);
		return true;
	}

	/**
	 * Adds a sequence of animations that will be added one after another.
	 * @param pAnimations The animation sequence to add.
	 * @return true if the sequence was added.
	 */
	public boolean addSequence(final BaseAnimation... pAnimations) {
		return addSequence(null, pAnimations);
	}

	/**
	 * Calls the animation update method or removes the animation if it is done.
	 * It also calls the "AnimationFinishListener" of the animation if it is done.
	 *
	 * @return False if no animation has been handled.
	 */

	public boolean update() {
		if (!enabled) {
			return false;
		}

		boolean didHandleAnimation = false;

		for (BaseAnimation animation: animations) {
			if (animation != null) {
				// for delayed animations.
				if (!animation.hasStarted() && animation.getTimeStartPlaned() != -1
						&& animation.getTimeStartPlaned() <= System.currentTimeMillis()) {
					animation.start();
					animation.setTimeStartPlaned(-1);
				}

				if (animation.isFinished()) {
					animations.remove(animation);
					animation.callAnimationFinishedListeners();
					if (animations.size() == 0 && allAnimationsFinishedListeners.size() > 0) {
						for (AnimationFinishedListener listener : allAnimationsFinishedListeners)
							listener.onAnimationFinished(null);

						allAnimationsFinishedListeners.clear();
					}

				} else {
					animation.update();
					didHandleAnimation = true;
				}
			}
		}

		return didHandleAnimation;
	}

	/**
	 * Gets the count of all animations.
	 * @return The count.
	 */
	public int getAnimationCount() {
		return animations.size();
	}

	/**
	 * Stops the animation the hard way.
	 * Does not call animation.onFinish nor its finish listeners.
	 * @param pAnimation The animation to cancel.
	 * @return True if the animation was found.
	 */
	public boolean cancel(BaseAnimation pAnimation) {
		return animations.remove(pAnimation);
	}

	/**
	 * Gracefully stops the animation and calls its listeners.
	 * @param pAnimation The animation to stop.
	 * @return True if the animation was found and stopped.
	 */
	public boolean stop(BaseAnimation pAnimation) {
		if (pAnimation != null) {
			if (cancel(pAnimation)) {
				pAnimation.onFinish();
				pAnimation.callAnimationFinishedListeners();
				return true;
			}
		}
		return false;
	}

	/**
	 * Cancels all animations without calling animation.onFinish or its listeners.
	 * @return This instance.
	 */
	public Ani resetHard() {
		for (BaseAnimation animation : animations) {
			cancel(animation);
		}
		return this;
	}

	/**
	 * Stops all animations and call animation.inFinish and the listeners.
	 * Disables this instance while stopping. Enables it afterwards.
	 * @return This instance.
	 */
	public Ani resetGraceful() {
		setEnabled(false);
		for (BaseAnimation animation : animations) {
			stop(animation);
		}
		setEnabled(true);
		return this;
	}

	/**
	 * Adds a listener that will be called if all animations of this controller are finished.
	 * @param pListener The listener to call.
	 * @return This instance.
	 */
	public Ani addAllAnimationFinishedListener(AnimationFinishedListener pListener) {
		allAnimationsFinishedListeners.add(pListener);
		return this;
	}

	/**
	 * Removes a listener scheduled to be called after all animations are finished.
	 * @param pListener The listener to remove
	 * @return True if the listener was registered in this controller and removed.
	 */
	public boolean removeAllAnimationFinishedListener(AnimationFinishedListener pListener) {
		return allAnimationsFinishedListeners.remove(pListener);
	}

	/**
	 * Stets a global factor to the animation speed.
	 * Value 1.0 is the standard value.
	 * The assigned value must be higher than 0.0.
	 * @param pTimeFactor The time factor to set for all animations.
	 */
	public static void setGlobalAnimationTimeFactor(float pTimeFactor) {
		if (pTimeFactor > 0.0f) {
			globalAnimationTimeFactor = pTimeFactor;
		} else
			throw new IllegalArgumentException("Time factor must be > 0");
	}

	/**
	 * Gets the global time factor used for all animations.
	 * @return The global time factor.
	 */
	public static float getGlobalTimeFactor() {
		return globalAnimationTimeFactor;
	}

	/**
	 * Indicates if this controller is at full capacity, defined by the animation limit.
	 * @return True if the controller is full
	 */
	public boolean full() {
		return animations.size() == animationsLimit;
	}

	/**
	 * Indicates if this controller is empty (has no animations)
	 * @return True if the animation count is 0.
	 */
	public boolean empty() {
		return animations.size() == 0;
	}

	/**
	 * Returns the size limit for this controller.
	 * @return Size limit.
	 */
	public int getLimit() {
		return animations.maxSize();
	}

	/**
	 * Enables and disables the controller.
	 * @param pEnabled The state.
	 * @return This instance.
	 */
	public Ani setEnabled(boolean pEnabled) {
		enabled = pEnabled;
		return this;
	}

	/**
	 * Returns the state of this controller.
	 * @return true if this instance is enabled.
	 */
	public boolean isEnabled() {
		return enabled;
	}

	/**
	 * Clears this controller and stops the timer, to make sure it's cleaned during garbage collection.
	 */
	public void clear() {
		run = false;
		enabled = false;
		animations.clear();
		allAnimationsFinishedListeners.clear();

		if (timer != null) {
			timer.cancel();
			timer.purge();
		}
	}
}
