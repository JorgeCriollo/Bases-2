package com.zero.animation.Collection;

import java.util.Iterator;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * This class provides a fixed size collection with O(1) access methods. Thread safe.
 * Note, however, that this is a trade-off exchanging memory for speed. Recommended only for fast operations that access
 * relatively small amounts of data.
 * @param <E>
 */
public class HashedArray<E> implements Iterable<E> {
    private final ConcurrentHashMap<E, Integer> indexDict;
    private final Object[] array;
    private final Queue<Integer> freeSlots;
    private int size;

    public HashedArray(int size) {
        indexDict = new ConcurrentHashMap<>(size);
        array = new Object[size];
        this.size = 0;

        freeSlots = new ConcurrentLinkedQueue<>();

        for (int i = 0; i < size; i++)
            freeSlots.offer(i);
    }

    /**
     * Attempts to add an item to the collection. The item will be added provided max size hasn't been reached.
     * @param item The item to add.
     * @return True if the item was added.
     */
    public boolean add(E item) {
        Objects.requireNonNull(item);

        if (size >= array.length || freeSlots.size() == 0)
            return false;

        int index = freeSlots.poll();

        indexDict.put(item, index);
        array[index] = item;
        size++;

        return true;
    }

    /**
     * Attempts to remove an item from the collection. The item will be removed if it was contained.
     * @param item The item to remove.
     * @return True if the item was contained in the collection and removed.
     */
    public boolean remove(E item) {
        Integer index;
        if ((index = indexDict.get(item)) != null) {
            array[index] = null;
            indexDict.remove(item);
            freeSlots.offer(index);
            size--;

            return true;
        }

        return false;
    }

    /**
     * Gets an item given it's index.
     * @param index Item's index.
     * @return Item corresponding to index position.
     */
    public E get(int index) {
        return (E) array[index];
    }

    /**
     * Verifies if the item is contained in this collection.
     * @param item The item to search.
     * @return True if the item is contained in this collection.
     */
    public boolean contains(E item) {
        return indexDict.contains(item);
    }

    /**
     * Clears the collection removing all items. The collection will be empty after this method is called.
     */
    public void clear() {
        indexDict.clear();
        freeSlots.clear();

        for (int i = 0; i < size; i++) {
            freeSlots.add(i);
            array[i] = null;
        }

        size = 0;
    }

    /**
     * Gets the size of the collection.
     * @return Size.
     */
    public int size() {
        return size;
    }

    /**
     * Gets the maximum size this collection can reach.
     * @return Maximum size.
     */
    public int maxSize() {
        return array.length;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int index = -1;
            @Override
            public boolean hasNext() {
                return index < array.length - 1;
            }

            @Override
            public E next() {
                index++;
                return (E) array[index];
            }
        };
    }

}
